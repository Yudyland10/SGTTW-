﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SGTTW.Startup))]
namespace SGTTW
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
