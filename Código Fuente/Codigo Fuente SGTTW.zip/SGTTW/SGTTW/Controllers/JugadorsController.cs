﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SGTTW.Models;

namespace SGTTW.Controllers
{
    public class JugadorsController : Controller
    {
        private DBSGTTWCONN db = new DBSGTTWCONN();

        // GET: Jugadors
        public async Task<ActionResult> Index()
        {
            var jugador = db.Jugador.Include(j => j.Nacionalidad);
            return View(await jugador.ToListAsync());
        }

        // GET: Jugadors/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jugador jugador = await db.Jugador.FindAsync(id);
            if (jugador == null)
            {
                return HttpNotFound();
            }
            return View(jugador);
        }

        // GET: Jugadors/Create
        public ActionResult Create()
        {
            ViewBag.NacionalidadId = new SelectList(db.Nacionalidad, "NacionalidadId", "Nombre");
            return View();
        }

        // POST: Jugadors/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "JugadorId,Apellidos,Nombres,NacionalidadId,Correo,Estado,Ranking")] Jugador jugador)
        {
            if (ModelState.IsValid)
            {
                db.Jugador.Add(jugador);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.NacionalidadId = new SelectList(db.Nacionalidad, "NacionalidadId", "Nombre", jugador.NacionalidadId);
            return View(jugador);
        }

        // GET: Jugadors/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jugador jugador = await db.Jugador.FindAsync(id);
            if (jugador == null)
            {
                return HttpNotFound();
            }
            ViewBag.NacionalidadId = new SelectList(db.Nacionalidad, "NacionalidadId", "Nombre", jugador.NacionalidadId);
            return View(jugador);
        }

        // POST: Jugadors/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "JugadorId,Apellidos,Nombres,NacionalidadId,Correo,Estado,Ranking")] Jugador jugador)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jugador).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.NacionalidadId = new SelectList(db.Nacionalidad, "NacionalidadId", "Nombre", jugador.NacionalidadId);
            return View(jugador);
        }

        // GET: Jugadors/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jugador jugador = await db.Jugador.FindAsync(id);
            if (jugador == null)
            {
                return HttpNotFound();
            }
            return View(jugador);
        }

        // POST: Jugadors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Jugador jugador = await db.Jugador.FindAsync(id);
            db.Jugador.Remove(jugador);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
